"""
Orchestrates the full pipeline for one document:

  1. Parse the file at the given path -> raw text
  2. Process for storage -> whitespace-stripped + base64 encoded
  3. Persist to Postgres
  4. Summarize the ORIGINAL raw text via Groq
  5. Return the summary (and the stored row id) to the caller
"""
import os

from parsers import extract_text
from processor import process_for_storage
from summarizer import summarize_text
from db import save_document


def handle_document(file_path: str) -> dict:
    file_path = os.path.expanduser(file_path.strip().strip('"').strip("'"))
    file_name = os.path.basename(file_path)
    file_type = os.path.splitext(file_path)[1].lower()

    # 1. Parse
    raw_text = extract_text(file_path)

    # 2. Process (whitespace removal + base64) for DB storage
    storage_fields = process_for_storage(raw_text)

    # 3. Summarize BEFORE the text is mangled for storage
    summary = summarize_text(raw_text, file_name)

    # 4. Persist
    doc_id, created_at = save_document(
        file_name=file_name,
        file_path=file_path,
        file_type=file_type,
        original_char_count=storage_fields["original_char_count"],
        cleaned_char_count=storage_fields["cleaned_char_count"],
        content_base64=storage_fields["content_base64"],
        summary=summary,
    )

    return {
        "id": doc_id,
        "created_at": created_at,
        "file_name": file_name,
        "file_type": file_type,
        "summary": summary,
        "original_char_count": storage_fields["original_char_count"],
        "cleaned_char_count": storage_fields["cleaned_char_count"],
    }
