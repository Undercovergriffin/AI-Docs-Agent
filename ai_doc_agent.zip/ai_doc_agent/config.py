"""
Central configuration. Loads everything from environment variables / .env
so no secrets are hard-coded in the codebase.
"""
import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    # Postgres
    PG_HOST = os.getenv("PG_HOST", "localhost")
    PG_PORT = os.getenv("PG_PORT", "5432")
    PG_DATABASE = os.getenv("PG_DATABASE", "doc_agent_db")
    PG_USER = os.getenv("PG_USER", "postgres")
    PG_PASSWORD = os.getenv("PG_PASSWORD", "")

    # Groq
    GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
    GROQ_MODEL = os.getenv("GROQ_MODEL", "llama-3.3-70b-versatile")

    SUPPORTED_EXTENSIONS = {".docx", ".txt", ".ppt", ".pptx", ".xlsx"}

    @classmethod
    def validate(cls):
        missing = []
        if not cls.GROQ_API_KEY:
            missing.append("GROQ_API_KEY")
        if not cls.PG_PASSWORD:
            missing.append("PG_PASSWORD")
        if missing:
            raise EnvironmentError(
                f"Missing required environment variables: {', '.join(missing)}. "
                f"Copy .env.example to .env and fill these in."
            )
