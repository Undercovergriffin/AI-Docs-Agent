"""
Thin data-access layer around psycopg2.
Create the `documents` table automatically if it doesn't exist yet
(same DDL as schema.sql, kept in sync manually).
"""
import psycopg2
from psycopg2.extras import RealDictCursor
from contextlib import contextmanager

from config import Config

_CREATE_TABLE_SQL = """
CREATE TABLE IF NOT EXISTS documents (
    id                  SERIAL PRIMARY KEY,
    file_name           TEXT NOT NULL,
    file_path           TEXT NOT NULL,
    file_type           TEXT NOT NULL,
    original_char_count INTEGER NOT NULL,
    cleaned_char_count  INTEGER NOT NULL,
    content_base64      TEXT NOT NULL,
    summary             TEXT,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
"""

_INSERT_SQL = """
INSERT INTO documents
    (file_name, file_path, file_type, original_char_count,
     cleaned_char_count, content_base64, summary)
VALUES (%s, %s, %s, %s, %s, %s, %s)
RETURNING id, created_at;
"""


@contextmanager
def get_connection():
    conn = psycopg2.connect(
        host=Config.PG_HOST,
        port=Config.PG_PORT,
        dbname=Config.PG_DATABASE,
        user=Config.PG_USER,
        password=Config.PG_PASSWORD,
    )
    try:
        yield conn
    finally:
        conn.close()


def init_db():
    """Create the documents table if it doesn't already exist."""
    with get_connection() as conn:
        with conn.cursor() as cur:
            cur.execute(_CREATE_TABLE_SQL)
        conn.commit()


def save_document(file_name, file_path, file_type, original_char_count,
                   cleaned_char_count, content_base64, summary):
    """Insert one processed document record. Returns (id, created_at)."""
    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                _INSERT_SQL,
                (file_name, file_path, file_type, original_char_count,
                 cleaned_char_count, content_base64, summary),
            )
            row = cur.fetchone()
        conn.commit()
    return row["id"], row["created_at"]


def fetch_document(doc_id):
    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute("SELECT * FROM documents WHERE id = %s;", (doc_id,))
            return cur.fetchone()


def list_documents(limit=20):
    with get_connection() as conn:
        with conn.cursor(cursor_factory=RealDictCursor) as cur:
            cur.execute(
                "SELECT id, file_name, file_type, created_at "
                "FROM documents ORDER BY created_at DESC LIMIT %s;",
                (limit,),
            )
            return cur.fetchall()
