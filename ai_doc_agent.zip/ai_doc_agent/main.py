"""
CLI entry point.

Usage:
    python main.py "/path/to/document.docx"

or run with no args for an interactive prompt loop.
"""
import sys

from config import Config
from db import init_db
from agent import handle_document


def run_once(path: str):
    try:
        result = handle_document(path)
    except Exception as e:
        print(f"\n[ERROR] {e}\n")
        return

    print("\n" + "=" * 60)
    print(f"Document : {result['file_name']} ({result['file_type']})")
    print(f"Saved as : documents.id = {result['id']} (at {result['created_at']})")
    print(f"Chars    : {result['original_char_count']} raw -> "
          f"{result['cleaned_char_count']} after whitespace removal")
    print("-" * 60)
    print("SUMMARY:\n")
    print(result["summary"])
    print("=" * 60 + "\n")


def main():
    Config.validate()
    init_db()

    if len(sys.argv) > 1:
        run_once(" ".join(sys.argv[1:]))
        return

    print("AI Document Agent — supported types: .docx .txt .ppt .pptx .xlsx")
    print("Enter a file path to parse & summarize (or 'quit' to exit).\n")
    while True:
        path = input("File path> ").strip()
        if path.lower() in ("quit", "exit"):
            break
        if not path:
            continue
        run_once(path)


if __name__ == "__main__":
    main()
