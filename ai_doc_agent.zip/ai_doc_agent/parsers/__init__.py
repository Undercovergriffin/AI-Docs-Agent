"""
Dispatches a file path to the correct extractor based on extension
and returns raw extracted text (whitespace intact).
"""
import os

from parsers.docx_parser import extract_docx
from parsers.txt_parser import extract_txt
from parsers.pptx_parser import extract_pptx
from parsers.xlsx_parser import extract_xlsx

_DISPATCH = {
    ".docx": extract_docx,
    ".txt": extract_txt,
    ".ppt": extract_pptx,   # note: legacy binary .ppt is NOT supported, see pptx_parser
    ".pptx": extract_pptx,
    ".xlsx": extract_xlsx,
}


def extract_text(file_path: str) -> str:
    if not os.path.isfile(file_path):
        raise FileNotFoundError(f"No such file: {file_path}")

    ext = os.path.splitext(file_path)[1].lower()
    if ext not in _DISPATCH:
        raise ValueError(
            f"Unsupported file type '{ext}'. Supported: {list(_DISPATCH.keys())}"
        )

    return _DISPATCH[ext](file_path)
