from docx import Document


def extract_docx(file_path: str) -> str:
    """Extract text from paragraphs and tables of a .docx file."""
    doc = Document(file_path)
    chunks = []

    for para in doc.paragraphs:
        if para.text.strip():
            chunks.append(para.text)

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                if cell.text.strip():
                    chunks.append(cell.text)

    return "\n".join(chunks)
