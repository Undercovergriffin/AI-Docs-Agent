import os
from pptx import Presentation


def extract_pptx(file_path: str) -> str:
    """Extract text from every shape/text-frame on every slide."""
    ext = os.path.splitext(file_path)[1].lower()
    if ext == ".ppt":
        raise ValueError(
            "Legacy binary .ppt files are not supported by python-pptx. "
            "Please convert the file to .pptx (e.g. open it in PowerPoint/"
            "LibreOffice and 'Save As' .pptx) and try again."
        )

    prs = Presentation(file_path)
    chunks = []

    for slide_index, slide in enumerate(prs.slides, start=1):
        for shape in slide.shapes:
            if shape.has_text_frame:
                for para in shape.text_frame.paragraphs:
                    text = "".join(run.text for run in para.runs)
                    if text.strip():
                        chunks.append(text)
            if shape.has_table:
                for row in shape.table.rows:
                    for cell in row.cells:
                        if cell.text.strip():
                            chunks.append(cell.text)

    return "\n".join(chunks)
