def extract_txt(file_path: str) -> str:
    """Read a plain-text file, tolerating minor encoding issues."""
    with open(file_path, "r", encoding="utf-8", errors="replace") as f:
        return f.read()
