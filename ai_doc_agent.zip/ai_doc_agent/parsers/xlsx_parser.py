from openpyxl import load_workbook


def extract_xlsx(file_path: str) -> str:
    """Extract every non-empty cell value from every sheet, row by row."""
    wb = load_workbook(file_path, data_only=True, read_only=True)
    chunks = []

    for sheet in wb.worksheets:
        chunks.append(f"--- Sheet: {sheet.title} ---")
        for row in sheet.iter_rows():
            values = [str(cell.value) for cell in row if cell.value is not None]
            if values:
                chunks.append(" | ".join(values))

    return "\n".join(chunks)
