"""
Post-extraction processing.

IMPORTANT DESIGN NOTE:
Removing all whitespace makes text unreadable for an LLM (words run
together), so the pipeline keeps two versions of the text:

  1. raw_text      -> used ONLY to generate the Groq summary
  2. cleaned_b64    -> whitespace stripped, then base64 encoded ->
                       this is what actually gets stored in Postgres,
                       per the requirement.
"""
import re
import base64


def remove_whitespace(text: str) -> str:
    """Strip ALL whitespace characters (spaces, tabs, newlines) from text."""
    return re.sub(r"\s+", "", text)


def to_base64(text: str) -> str:
    """UTF-8 encode then base64 encode a string, return as ascii string."""
    return base64.b64encode(text.encode("utf-8")).decode("ascii")


def from_base64(b64_text: str) -> str:
    """Reverse of to_base64, for retrieval/debugging."""
    return base64.b64decode(b64_text.encode("ascii")).decode("utf-8")


def process_for_storage(raw_text: str) -> dict:
    """
    Returns a dict with everything needed to persist a row:
      - cleaned_char_count
      - content_base64
    """
    cleaned = remove_whitespace(raw_text)
    return {
        "original_char_count": len(raw_text),
        "cleaned_char_count": len(cleaned),
        "content_base64": to_base64(cleaned),
    }
