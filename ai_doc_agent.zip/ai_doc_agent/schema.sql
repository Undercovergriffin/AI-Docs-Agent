-- Run this once in pgAdmin's Query Tool against your target database
-- (or let db.py -> init_db() create it automatically at first run).

CREATE TABLE IF NOT EXISTS documents (
    id                  SERIAL PRIMARY KEY,
    file_name           TEXT NOT NULL,
    file_path           TEXT NOT NULL,
    file_type           TEXT NOT NULL,
    original_char_count INTEGER NOT NULL,
    cleaned_char_count  INTEGER NOT NULL,
    content_base64      TEXT NOT NULL,   -- whitespace-stripped text, base64 encoded
    summary             TEXT,            -- Groq-generated summary
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_documents_file_name ON documents (file_name);
