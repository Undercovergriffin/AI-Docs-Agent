"""
Calls Groq's free-tier chat completion API to summarize extracted text.
"""
from groq import Groq
from config import Config

_MAX_INPUT_CHARS = 60_000  # crude guard to stay within model context on free tier

_client = None


def _get_client() -> Groq:
    global _client
    if _client is None:
        _client = Groq(api_key=Config.GROQ_API_KEY)
    return _client


def summarize_text(raw_text: str, file_name: str) -> str:
    if not raw_text.strip():
        return "(No extractable text found in this document.)"

    text_for_model = raw_text[:_MAX_INPUT_CHARS]

    client = _get_client()
    response = client.chat.completions.create(
        model=Config.GROQ_MODEL,
        messages=[
            {
                "role": "system",
                "content": (
                    "You are a precise document-summarization assistant. "
                    "Summarize the given document content in 3-6 concise "
                    "sentences, then list up to 5 key points as bullets. "
                    "Do not invent information that isn't in the text."
                ),
            },
            {
                "role": "user",
                "content": f"Document: {file_name}\n\nContent:\n{text_for_model}",
            },
        ],
        temperature=0.3,
        max_tokens=500,
    )
    return response.choices[0].message.content.strip()
